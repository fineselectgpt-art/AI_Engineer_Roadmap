
# STAR Stories (Interview Prep)

Write 6 stories using this structure.

## Story: <Title>

**Situation:**  
**Task:**  
**Action:**  
**Result:**  

### What I’d do differently next time
-
