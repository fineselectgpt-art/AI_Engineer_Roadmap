
# Experiment Report

## Goal
What are we trying to improve and why?

## Baseline
- Model:
- Features:
- Metric(s):

## Changes Tested
1. Change:
   - Rationale:
   - What changed in code:

## Results
| Experiment | Metric | Notes |
|---|---:|---|
| baseline |  |  |
| exp-1 |  |  |

## Error Analysis
- Worst cases:
- Segments with weak performance:
- Hypothesis:

## Next Steps
- [ ] ...
